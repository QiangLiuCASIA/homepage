#! /usr/bin/env python

import csv
import itertools
import numpy as np
import time
import sys
import operator
import io
import array
from datetime import datetime
from gru_theano import GRUTheano


def load_data(dir = "./data/items.txt"):
    f = open(dir,'r')
    x_train = []
    x_test = []
    while 1:
        s = f.readline()
        if not s:
            break;
        s = s.strip()
        ss = s.split('\t')

        sentence = []
        for word in ss:
            sentence.append(int(word))
        x_train.append(sentence[0:len(sentence)-1])
        x_test.append(sentence[1:len(sentence)])


    f.close()
    x_train = np.asarray(x_train)
    x_test = np.asarray(x_test)
    return x_train, x_test


def train_with_sgd(model, x_train, x_test, learning_rate=0.001, nepoch=20,
    callback_every=10000, callback=None):
    num_examples_seen = 0
    for epoch in range(nepoch):
        # For each training example...
        for i in np.random.permutation(len(x_test)):
            # One SGD step
            model.sgd_step(x_train[i], x_test[i], learning_rate)
            num_examples_seen += 1
            # Optionally do callback
            if (callback and callback_every and num_examples_seen % callback_every == 0):
                callback(model, num_examples_seen)            
    return model

def save_model_parameters_theano(model, outfile):
    np.savez(outfile,
        E=model.E.get_value(),
        U=model.U.get_value(),
        W=model.W.get_value())
    print "Saved model parameters to %s." % outfile

def load_model_parameters_theano(path, modelClass=GRUTheano):
    npzfile = np.load(path)
    E, U, W = npzfile["E"], npzfile["U"], npzfile["W"]
    hidden_dim, item_number = E.shape[0], E.shape[1]
    print "Building model model from %s with hidden_dim=%d" % (path, hidden_dim)
    model = modelClass(item_number, hidden_dim)
    model.E.set_value(E)
    model.U.set_value(U)
    model.W.set_value(W)
    return model 

