import numpy as np
import theano as theano
import theano.tensor as T
from sklearn import metrics
from gru_theano import GRUTheano

def load_model_parameters_theano(path, modelClass=GRUTheano):
    npzfile = np.load(path)
    E, U, W = npzfile["E"], npzfile["U"], npzfile["W"]
    hidden_dim, item_number = E.shape[0], E.shape[1]
    print "Building model model from %s with hidden_dim=%d" % (path, hidden_dim)
    model = modelClass(item_number, hidden_dim)
    model.E.set_value(E)
    model.U.set_value(U)
    model.W.set_value(W)
    return model 

def test(path):
    model = load_model_parameters_theano(path)
    
    f = open('test.txt','r')
    log = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split('\t')
        temp = []
        for word in ss:
            temp.append(int(word))
        log.append(temp)
    
    f = open('test_id.txt','r')
    train = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split('\t')
        temp = []
        for word in ss:
            temp.append(int(word))
        train.append(temp)
    
    results = 0.0
    total = 0
    for i in range(len(log)):
        for j in range(len(log[i])-1):
            if train[i][j+1]==1:
                total = total+1
                x = log[i][0:j+1]
                y = log[i][j+1]
                
                probs = model.predict(x)[-1]
                des = np.zeros(1157)
                des[y] = 1
                fpr, tpr, thresholds = metrics.roc_curve(des, probs, pos_label=1)
                temp = metrics.auc(fpr, tpr)
                results += temp

    results = results/total
    print results
    return results

if __name__ == '__main__':
    f = open('paths.txt','r')
    o = open('results.txt','w')
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        out = test(s)
        o.write(str(out)+'\n')
    f.close()
    o.close()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    