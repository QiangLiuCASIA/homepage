#! /usr/bin/env python

import sys
import os
import time
import numpy as np
from utils import *
from datetime import datetime
from gru_theano import GRUTheano

LEARNING_RATE = float(os.environ.get("LEARNING_RATE", "0.001"))
ITEM_NUMBER = int(os.environ.get("ITEM_NUMBER", "1157"))
HIDDEN_DIM = int(os.environ.get("HIDDEN_DIM", "10"))
NEPOCH = int(os.environ.get("NEPOCH", "300"))
INPUT_DATA_FILE = os.environ.get("INPUT_DATA_FILE", "./data/train.txt")
PRINT_EVERY = int(os.environ.get("PRINT_EVERY", "1904"))

# Load data
x_train, x_test = load_data(INPUT_DATA_FILE)
		
model = GRUTheano(ITEM_NUMBER, hidden_dim=HIDDEN_DIM, bptt_truncate=-1)

# Print SGD step time
t1 = time.time()
model.sgd_step(x_train[10], x_test[10], LEARNING_RATE)
t2 = time.time()
print "SGD Step time: %f milliseconds" % ((t2 - t1) * 1000.)

# We do this every few examples to understand what's going on
def sgd_callback(model, num_examples_seen):
  dt = datetime.now().isoformat()
  loss = model.calculate_loss(x_train[:1000], x_test[:1000])
  print("\n%s (%d)" % (dt, num_examples_seen))
  print("--------------------------------------------------")
  print("Loss: %f" % loss)
  ts = datetime.now().strftime("%Y-%m-%d-%H-%M-%S")
  MODEL_OUTPUT_FILE = "models/GRU-%s.dat" % (ts)
  save_model_parameters_theano(model, MODEL_OUTPUT_FILE)
  print("\n")

for epoch in range(NEPOCH):
  train_with_sgd(model, x_train, x_test, learning_rate=LEARNING_RATE, nepoch=1,
    callback_every=PRINT_EVERY, callback=sgd_callback)