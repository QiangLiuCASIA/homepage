#! /usr/bin/env python

import sys
import os
import time
import numpy as np
from utils import *
from datetime import datetime
from gru_theano import GRUTheano

LEARNING_RATE = float(os.environ.get("LEARNING_RATE", "0.001"))
ITEM_NUMBER = int(os.environ.get("ITEM_NUMBER", "2729"))
CONTEXT_NUMBER = int(os.environ.get("CONTEXT_NUMBER", "22"))
HIDDEN_DIM = int(os.environ.get("HIDDEN_DIM", "10"))
NEPOCH = int(os.environ.get("NEPOCH", "50"))
MODEL_OUTPUT_FILE = os.environ.get("MODEL_OUTPUT_FILE", "models/CA-GRU.dat")
INPUT_DATA_FILE = os.environ.get("INPUT_DATA_FILE", "./data/items.txt")
C0_DATA_FILE = os.environ.get("USER_DATA_FILE", "./data/c0.txt")
C1_DATA_FILE = os.environ.get("USER_DATA_FILE", "./data/c1.txt")
C2_DATA_FILE = os.environ.get("USER_DATA_FILE", "./data/c2.txt")
C3_DATA_FILE = os.environ.get("USER_DATA_FILE", "./data/c3.txt")
PRINT_EVERY = int(os.environ.get("PRINT_EVERY", "839"))

# Load data
x_train, x_test, c0_train, c0_test, c1_train, c1_test, c2_train, c2_test, c3_train, c3_test = load_data(INPUT_DATA_FILE, C0_DATA_FILE, C1_DATA_FILE, C2_DATA_FILE, C3_DATA_FILE)
		
path = './models/GRU-2016-08-04-01-58.dat.npz'
model = load_model_parameters_theano(path)

# Print SGD step time
t1 = time.time()
model.sgd_step(x_train[10], c0_train[10], c0_test[10], c1_train[10], c1_test[10], c2_train[10], c2_test[10], c3_train[10], c3_test[10], x_test[10], LEARNING_RATE)
t2 = time.time()
print "SGD Step time: %f milliseconds" % ((t2 - t1) * 1000.)

# We do this every few examples to understand what's going on
def sgd_callback(model, num_examples_seen):
  dt = datetime.now().isoformat()
  loss = model.calculate_loss(x_train[:839], c0_train[:839], c0_test[:839], c1_train[:839], c1_test[:839], c2_train[:839], c2_test[:839], c3_train[:839], c3_test[:839], x_test[:839])
  print("\n%s (%d)" % (dt, num_examples_seen))
  print("--------------------------------------------------")
  print("Loss: %f" % loss)
  ts = datetime.now().strftime("%Y-%m-%d-%H-%M")
  MODEL_OUTPUT_FILE = "models/GRU-%s.dat" % (ts)
  save_model_parameters_theano(model, MODEL_OUTPUT_FILE)
  print("\n")

for epoch in range(NEPOCH):
  train_with_sgd(model, x_train, c0_train, c0_test, c1_train, c1_test, c2_train, c2_test, c3_train, c3_test, x_test, learning_rate=LEARNING_RATE, nepoch=1, decay=0.9, 
    callback_every=PRINT_EVERY, callback=sgd_callback)