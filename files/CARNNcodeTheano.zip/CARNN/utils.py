#! /usr/bin/env python

import csv
import itertools
import numpy as np
import time
import sys
import operator
import io
import array
from datetime import datetime
from gru_theano import GRUTheano

def load_data(dir = "./data/items.txt", dir0 = "./data/c0.txt", dir1 = "./data/c1.txt", dir2 = "./data/c2.txt"):
    f = open(dir,'r')
    f0 = open(dir0,'r')
    f1 = open(dir1,'r')
    f2 = open(dir2,'r')
    x_train = []
    x_test = []
    c0_train = []
    c0_test = []
    c1_train = []
    c1_test = []
    c2_train = []
    c2_test = []
    while 1:
        s = f.readline()
        s0 = f0.readline()
        s1 = f1.readline()
        s2 = f2.readline()
        if not s:
            break;
        s = s.strip()
        s0 = s0.strip()
        s1 = s1.strip()
        s2 = s2.strip()
        ss = s.split('\t')
        ss0 = s0.split('\t')
        ss1 = s1.split('\t')
        ss2 = s2.split('\t')

        sentence = []
        for word in ss:
            sentence.append(int(word))
        x_train.append(sentence[0:len(sentence)-1])
        x_test.append(sentence[1:len(sentence)])

        sentence = []
        for word in ss0:
            sentence.append(int(word))
        c0_train.append(sentence[0:len(sentence)-1])
        c0_test.append(sentence[1:len(sentence)])

        sentence = []
        for word in ss1:
            sentence.append(int(word))
        c1_train.append(sentence[0:len(sentence)-1])
        c1_test.append(sentence[1:len(sentence)])

        sentence = []
        for word in ss2:
            sentence.append(int(word))
        c2_train.append(sentence[0:len(sentence)-1])
        c2_test.append(sentence[1:len(sentence)])


    f.close()
    f0.close()
    f1.close()
    f2.close()
    x_train = np.asarray(x_train)
    x_test = np.asarray(x_test)
    c0_train = np.asarray(c0_train)
    c0_test = np.asarray(c0_test)
    c1_train = np.asarray(c1_train)
    c1_test = np.asarray(c1_test)
    c2_train = np.asarray(c2_train)
    c2_test = np.asarray(c2_test)
    return x_train, x_test, c0_train, c0_test, c1_train, c1_test, c2_train, c2_test


def train_with_sgd(model, x_train, c0_train, c0_test, c1_train, c1_test, c2_train, c2_test, x_test, learning_rate=0.001, nepoch=20,
    callback_every=10000, callback=None):
    num_examples_seen = 0
    for epoch in range(nepoch):
        # For each training example...
        for i in np.random.permutation(len(x_test)):
            # One SGD step
            model.sgd_step(x_train[i], c0_train[i], c0_test[i], c1_train[i], c1_test[i], c2_train[i], c2_test[i], x_test[i], learning_rate)
            num_examples_seen += 1
            # Optionally do callback
            if (callback and callback_every and num_examples_seen % callback_every == 0):
                callback(model, num_examples_seen)            
    return model

def save_model_parameters_theano(model, outfile):
    np.savez(outfile,
        E=model.E.get_value(),
        U=model.U.get_value(),
        W=model.W.get_value(),
        M=model.M.get_value(),
        N=model.N.get_value())
    print "Saved model parameters to %s." % outfile

def load_model_parameters_theano(path, modelClass=GRUTheano):
    npzfile = np.load(path)
    E, P, U, W, M, N, b, c = npzfile["E"], npzfile["P"], npzfile["U"], npzfile["W"], npzfile["M"], npzfile["N"], npzfile["b"], npzfile["c"]
    hidden_dim, item_number = E.shape[0], E.shape[1]
    hidden_dim, context_number = P.shape[0], P.shape[1]
    print "Building model model from %s with hidden_dim=%d" % (path, hidden_dim)
    model = modelClass(item_number, context_number, hidden_dim)
    model.E.set_value(E)
    model.P.set_value(P)
    model.U.set_value(U)
    model.W.set_value(W)
    model.M.set_value(M)
    model.N.set_value(N)
    model.b.set_value(b)
    model.c.set_value(c)
    return model 

