import numpy as np
import theano as theano
import theano.tensor as T
from sklearn import metrics
from gru_theano import GRUTheano

def load_model_parameters_theano(path, modelClass=GRUTheano):
    npzfile = np.load(path)
    E, U, W, M, N = npzfile["E"], npzfile["U"], npzfile["W"], npzfile["M"], npzfile["N"]
    hidden_dim, item_number = E.shape[0], E.shape[1]
    context_number = U.shape[0]
    print "Building model model from %s with hidden_dim=%d" % (path, hidden_dim)
    model = modelClass(item_number, context_number, hidden_dim)
    model.E.set_value(E)
    model.U.set_value(U)
    model.W.set_value(W)
    model.M.set_value(M)
    model.N.set_value(N)
    return model 

def test(path):
    model = load_model_parameters_theano(path)
    
    f = open('test.txt','r')
    log = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split('\t')
        temp = []
        for word in ss:
            temp.append(int(word))
        log.append(temp)
    
    f = open('test_id.txt','r')
    train = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split('\t')
        temp = []
        for word in ss:
            temp.append(int(word))
        train.append(temp)
    
    f = open('c0.txt','r')
    c0 = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split('\t')
        temp = []
        for word in ss:
            temp.append(int(word))
        c0.append(temp)
    
    f = open('c1.txt','r')
    c1 = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split('\t')
        temp = []
        for word in ss:
            temp.append(int(word))
        c1.append(temp)
    
    f = open('c2.txt','r')
    c2 = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split('\t')
        temp = []
        for word in ss:
            temp.append(int(word))
        c2.append(temp)
    
    results = []
    total = 0
    for i in range(len(log)):
        for j in range(len(log[i])-1):
            if train[i][j+1]==1:
                total = total+1
                x = log[i][0:j+1]
                y = log[i][j+1]
                c00 = c0[i][0:j+1]
                c01 = c0[i][0:j+2]
                c10 = c1[i][0:j+1]
                c11 = c1[i][0:j+2]
                c20 = c2[i][0:j+1]
                c21 = c2[i][0:j+2]
                
                probs = model.predict(x, c00, c01, c10, c11, c20, c21)[-1]
                des = np.zeros(1157)
                des[y] = 1
                fpr, tpr, thresholds = metrics.roc_curve(des, probs, pos_label=1)
                temp = metrics.auc(fpr, tpr)
                results.append(temp)

    results = np.array(results)
    results = np.mean(results)
    print results
    return results

if __name__ == '__main__':
    f = open('paths.txt','r')
    o = open('results.txt','w')
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        out = test(s)
        o.write(str(out)+'\n')
    f.close()
    o.close()
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    