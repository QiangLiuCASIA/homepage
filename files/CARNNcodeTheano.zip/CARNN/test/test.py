import numpy as np
import theano as theano
import theano.tensor as T
from theano.gradient import grad_clip
import time
import operator
from datetime import datetime
from gru_theano import GRUTheano

def load_model_parameters_theano(path, modelClass=GRUTheano):
    npzfile = np.load(path)
    E, U, W, M, N = npzfile["E"], npzfile["U"], npzfile["W"], npzfile["M"], npzfile["N"]
    hidden_dim, item_number = E.shape[0], E.shape[1]
    context_number = U.shape[0]
    print "Building model model from %s with hidden_dim=%d" % (path, hidden_dim)
    model = modelClass(item_number, context_number, hidden_dim)
    model.E.set_value(E)
    model.U.set_value(U)
    model.W.set_value(W)
    model.M.set_value(M)
    model.N.set_value(N)
    return model 

if __name__ == '__main__':
    path = 'GRU-2016-08-04-12-08.dat.npz'
    model = load_model_parameters_theano(path)
    
    f = open('items.txt','r')
    log = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split(' ')
        temp = []
        for word in ss:
            temp.append(int(word))
        log.append(temp)
    
    f = open('train.txt','r')
    train = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split(' ')
        temp = []
        for word in ss:
            temp.append(int(word))
        train.append(temp)
    
    f = open('c0.txt','r')
    c0 = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split(' ')
        temp = []
        for word in ss:
            temp.append(int(word))
        c0.append(temp)
    
    f = open('c1.txt','r')
    c1 = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split(' ')
        temp = []
        for word in ss:
            temp.append(int(word))
        c1.append(temp)
    
    f = open('c2.txt','r')
    c2 = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split(' ')
        temp = []
        for word in ss:
            temp.append(int(word))
        c2.append(temp)
    
    f = open('c3.txt','r')
    c3 = []
    while 1:
        s = f.readline()
        if not s:
            break
        s = s.strip()
        ss = s.split(' ')
        temp = []
        for word in ss:
            temp.append(int(word))
        c3.append(temp)
    
    rank = np.zeros(20)
    total = 0
    for i in range(len(log)):
        print i
        for j in range(len(log[i])-1):
            if train[i][j+1]==1:
                total = total+1
                x = log[i][0:j+1]
                y = log[i][j+1]
                c00 = c0[i][0:j+1]
                c01 = c0[i][0:j+2]
                c10 = c1[i][0:j+1]
                c11 = c1[i][0:j+2]
                c20 = c2[i][0:j+1]
                c21 = c2[i][0:j+2]
                c30 = c3[i][0:j+1]
                c31 = c3[i][0:j+2]
                
                probs = model.predict(x, c00, c01, c10, c11, c20, c21, c30, c31)[-1]
                des = probs[y]
                probs.sort()
                position = 1000
                for k in range(50):
                    if probs[len(probs)-k-1]==des:
                        position = k
                        break
                for k in range(20):
                    if position<=k:
                        rank[k] = rank[k]+1
        temp = np.zeros(20)
        for k in range(20):
            temp[k] = rank[k]/total
        print temp
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    
    