import numpy as np
import theano as theano
import theano.tensor as T
from theano.gradient import grad_clip
import time
import operator

class GRUTheano:
    
    def __init__(self, item_number, context_number, hidden_dim=10, bptt_truncate=-1):
        # Assign instance variables
        self.item_number = item_number
        self.context_number = context_number
        self.hidden_dim = hidden_dim
        self.bptt_truncate = bptt_truncate
        # Initialize the network parameters
        E = np.random.uniform(-np.sqrt(1./item_number), np.sqrt(1./item_number), (hidden_dim, item_number))
        U = np.random.uniform(-np.sqrt(1./hidden_dim), np.sqrt(1./hidden_dim), (context_number, hidden_dim, hidden_dim))
        W = np.random.uniform(-np.sqrt(1./hidden_dim), np.sqrt(1./hidden_dim), (context_number, hidden_dim, hidden_dim))
        M = np.random.uniform(-np.sqrt(1./hidden_dim), np.sqrt(1./hidden_dim), (context_number, hidden_dim, hidden_dim))
        N = np.random.uniform(-np.sqrt(1./hidden_dim), np.sqrt(1./hidden_dim), (context_number, hidden_dim, hidden_dim))
        # Theano: Created shared variables
        self.E = theano.shared(name='E', value=E.astype(theano.config.floatX))
        self.U = theano.shared(name='U', value=U.astype(theano.config.floatX))
        self.W = theano.shared(name='W', value=W.astype(theano.config.floatX))
        self.M = theano.shared(name='M', value=M.astype(theano.config.floatX))
        self.N = theano.shared(name='N', value=N.astype(theano.config.floatX))
        # We store the Theano graph here
        self.theano = {}
        self.__theano_build__()
    
    def __theano_build__(self):
        E, U, W, M, N = self.E, self.U, self.W, self.M, self.N
        
        x = T.ivector('x')
        y = T.ivector('y')
        c00 = T.ivector('c00')
        c01 = T.ivector('c01')
        c10 = T.ivector('c10')
        c11 = T.ivector('c11')
        c20 = T.ivector('c20')
        c21 = T.ivector('c21')
        
        def forward_prop_step(x_t, c00_t, c01_t, c10_t, c11_t, c20_t, c21_t, s_t_prev):
            
            # Word embedding layer
            x_e = E[:,x_t]
            W0_e = W[c00_t]
            W1_e = M[c01_t]
            U0_e = U[c10_t] + U[c20_t]
            U1_e = N[c11_t] + N[c21_t]
            
            # RNN Layer
            s_t = T.tanh(U0_e.dot(x_e) + W0_e.dot(s_t_prev))
            
            # Final output calculation
            # Theano's softmax returns a matrix with one row, we only need the row
            V = E.transpose().dot(W1_e+U1_e)
            o_t = T.nnet.softmax(V.dot(s_t))[0]

            return [o_t, s_t]
        
        [o, s], updates = theano.scan(
            forward_prop_step,
            sequences=[x, c00, c01, c10, c11, c20, c21],
            truncate_gradient=self.bptt_truncate,
            outputs_info=[None, 
                          dict(initial=T.zeros(self.hidden_dim))])
        
        prediction = T.argmax(o, axis=1)
        o_error = T.sum(T.nnet.categorical_crossentropy(o, y))
        
        # Total cost (could add regularization here)
        cost = o_error
        
        # Gradients
        dE = T.grad(cost, E)
        dU = T.grad(cost, U)
        dW = T.grad(cost, W)
        dM = T.grad(cost, M)
        dN = T.grad(cost, N)
        
        # Assign functions
        self.predict = theano.function([x, c00, c01, c10, c11, c20, c21], o)
        self.predict_class = theano.function([x, c00, c01, c10, c11, c20, c21], prediction)
        self.ce_error = theano.function([x, c00, c01, c10, c11, c20, c21, y], cost)
        self.bptt = theano.function([x, c00, c01, c10, c11, c20, c21, y], [dE, dU, dW, dM, dN])
        
        # SGD parameters
        learning_rate = T.scalar('learning_rate')
        
        self.sgd_step = theano.function(
            [x, c00, c01, c10, c11, c20, c21, y, learning_rate],
            [], 
            updates=[(E, E - learning_rate * dE),
                     (U, U - learning_rate * dU),
                     (W, W - learning_rate * dW),
                     (M, M - learning_rate * dM),
                     (N, N - learning_rate * dN)
                    ])
        
        
    def calculate_total_loss(self, X, C00, C01, C10, C11, C20, C21, Y):
        return np.sum([self.ce_error(x,c00,c01,c10,c11,c20,c21,y) for x,c00,c01,c10,c11,c20,c21,y in zip(X,C00,C01,C10,C11,C20,C21,Y)])
    
    def calculate_loss(self, X, C00, C01, C10, C11, C20, C21, Y):
        # Divide calculate_loss by the number of words
        num_words = np.sum([len(y) for y in Y])
        return self.calculate_total_loss(X,C00,C01,C10,C11,C20,C21,Y)/float(num_words)

