#!/usr/bin/env python
# -*- coding: utf-8 -*-
import numpy as np


a = np.load('embedding.npy')
print a

