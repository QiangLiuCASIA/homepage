import json


f = open("./param/tmall/prediction.json")
a = json.load(f)
print "num is : %d"% len(a)
different = []
dif_ago = 0
for id, aa in enumerate(a):
    if id == 0:
        # print aa
        different.append(id)
    elif aa != a[id-1]:
        # print aa
        different.append(id)
        # if id != dif_ago + 1:
        #     # print id
        dif_ago = id
print "rest num is %d" % len(different)

