#!/usr/bin/env python
# -*- coding: utf-8 -*-
import numpy as np
import theano
import theano.tensor as T
import os
import random
import json
import time
import sys
import math
from util.seeresult import seeresult

# from rnn_use_theano_czy.rnn_use_theano import Rnn
from model.rnnwithbpr_theano_czy import RCnnWithBpr
from util.preprocess import negative
from util.postprocess import f1_score5, ndcg5, prediction_save
from util.Loader import Loader
#
# # test
# test_y = [1,2,3,4,5,6,-1, -1, -1]
# pre_y = [1, 12, 12 , 1000, 1000]
# p1,p2,p3 = f1_score5(pre_y, test_y, 1000)
# ndcg = ndcg5(pre_y, test_y, 1000)
# f1 = p1*2/(p1*2 + p2 + p3)


def main():
    #  首先把各种参数都给定义了
    s = {
        'learning_rate': 0.0025,
        'learning_rate_decay_epoch': 100.0,
        'lamda': 0.0025,  # tmall 数据下lamda再0.0025比较好   tafeng数据还没测
        'verbose': True,
        # 'basket_size': 2,
        'n_hidden': 0,  # 在有bpr的情况下embedding等于hidden
        'embedding_dimension': 10,
        'max_epoch': 1000,
        'withbpr': True,
        'continue': False,
        'dataset_name': 'tmall',  # Tmall or tafeng
        'data_dir': 'data/tmall',  # data/tafeng or data/tmall
        'isrank':True,
        'param_dir':'param'
    }
    folder = os.path.split(os.path.realpath(__file__))[0]
    folder = os.path.join(folder, s['param_dir'], s['dataset_name'])
    better_f1_score = 0
    better_ndcg = 0
    better_epoch_f1 = 0
    better_epoch_ndcg = 0
    test_result = []
    if s['withbpr']:
        # s['window_size'] = 1
        s['n_hidden'] = s['embedding_dimension']
    if s['verbose']:
        print("===================RNN训练模型====================\n数据输入...")
    # 下面是数据处理，我先用tmall的数据试试水
    # [user_rank, num_items, num_users, items_id] = file_load_tmall()
    loader = Loader(s['dataset_name'], s["data_dir"], s["isrank"])
    num_users = loader.user_size
    s["basket_size"] = loader.max_basket_l
    # # 数据需要整理一下，要让商品编号映射到一个序列items_id上去
    # dict_item = {items_id[i]: i for i in range(num_items)}
    # for i in range(num_users):
    #      for j in range(len(user_rank[i])):
    #          user_rank[i][j] = dict_item[user_rank[i][j]]
    if s['verbose']:
        print("\n数据输入完成\n-------模型建立---------\n")
    # 建立Rnn实例
    recommender = RCnnWithBpr(s['basket_size'], s['n_hidden'], loader.item_size + 1, s['embedding_dimension'])
    # item_size + 1是为了有最后一行留给-1，空物品
    if s['continue']:
        recommender.load_params(folder)
        print(">>过去原有模型参数导入成功！<<")
    if s['verbose']:
        print("模型建立成功！\n--------模型训练--------\n")
    # 进入循环
    epoch = 0
    # while epoch < s['max_epoch']:
    if s['verbose']:
        print("训练开始...")
    tic = time.time()
    while True:
        epoch += 1
        if s["verbose"]:
            print("\n 第%i次迭代..." % epoch)
        cost = 0
        interation = 0
        ndcg = 0.0
        tp = 0.0
        fn = 0.0
        fp = 0.0
        default_num = 0
        user_feature = []
        num_users = loader.user_size
        result = []
        loader.reset_batch_pointer()
        learning_rate = s['learning_rate']/math.ceil(epoch/s['learning_rate_decay_epoch'])
        print "learning_rate"
        print learning_rate
        for line, basket_size in loader.next_user():
            if len(line) < 3:
                num_users -= 1
                continue
            interation += 1
            # 窗化处理  数据本身是处理好的
            # 数据整理
            train_neg = np.asarray(negative(line, loader.item_size)[0:-1]).astype('int32')
            train_x = np.asarray(line[0:-1]).astype('int32')
            train_size = np.asarray(basket_size[0:-1]).astype('int32')
            # train_y = np.asarray(line1[-2]).astype('int32')
            test_x = np.asarray(line[0:-1]).astype('int32')
            test_y = np.asarray(line[-1]).astype('int32')
            test_size = np.asarray(basket_size[0:-1]).astype('int32')
            # len_train = train_x.shape[0]
            # len_test = test_x.shape[0]
            # a = recommender.test_h(train_x, train_neg, train_size)
            # b = recommender.test_h2(train_x)
            # 训练
            # embedding = recommender.embedding.get_value()
            # x =embedding[train_x]
            # y = embedding[train_neg]
            cost += recommender.train(train_x, train_neg, train_size, learning_rate, s['lamda'])
            # recommender.normalize()
            # embedding = recommender.embedding.get_value()
            # embedding[-1] = 0.
            # recommender.embedding.set_value(embedding.astype(theano.config.floatX))
            # 计时显示
            if s['verbose']:
                print "本次已经完成了：%2.2f%%" % (interation * 100. / num_users), \
                    "已花费了：%.2f 秒\r" % (time.time() - tic),
                sys.stdout.flush()
            # 测试
            if epoch > 1:
                recall_6_y = recommender.evaluation_recall_6(test_x, test_size)
                # user_feature.append(list(recommender.test_h(test_x).reshape(s['n_hidden'])))
                # recall_6_y = [1419, 18, 453, 79, 502, 227]
                if long(loader.item_size) in set(recall_6_y):
                    recall_5_y = []
                    default_num += 1
                    for recall in recall_6_y:
                        if long(loader.item_size) != recall:
                            recall_5_y.append(recall)
                else:
                    recall_5_y = recall_6_y[0:-1]
                result.append(list(recall_5_y))
                if epoch < 3:
                    test_result.append(list(test_y))
                # print "recall_5"
                # print recall_5_y
                # print "test"
                # print test_y
                # print "h"
                tp_p, fn_p, fp_p = f1_score5(recall_5_y, test_y, loader.item_size)
                tp += tp_p
                fn += fn_p
                fp += fp_p
                # if tp != recall_5:
                ndcg += ndcg5(recall_5_y, test_y, loader.item_size)
                # print ndcg5(recall_5_y, test_y)
        if epoch > 1:
            # print("\n第%i次迭代..." % epoch)
            # print tp, fn, fp
            f1_score = 2 * tp/(2*tp + fn + fp)
            if epoch < 3:
                prediction_save(folder, 'ground_true', test_result)
            if float(f1_score) > better_f1_score:
                    better_f1_score = float(f1_score)
                    better_epoch_f1 = epoch
                    recommender.save_params(folder)
                    better_result = result
                    prediction_save(folder, 'prediction', better_result)
                    prediction_save(folder, 'user_feature', user_feature)
            if float(ndcg) / num_users > better_ndcg:
                    better_ndcg = float(ndcg) / num_users
                    better_epoch_ndcg = epoch
            if s["verbose"]:
                # print("recall@10为：%f" % (float(recall_10) / num_users))
                print("\n cost为%.2f\n  recall@5为：%f\n F1_score@5为：%f\n NDCG@5为：%f" %
                      (cost, tp / loader.predict_num, f1_score, ndcg/num_users))
                print("最佳的F1_score结果出现在第%i次迭代，bset_f1_score@5为：%f" % (better_epoch_f1, better_f1_score))
                print("最佳的NDCG结果出现在第%i次迭代，bset_ndcg@5为：%f" % (better_epoch_ndcg, better_ndcg))
                seeresult()
                print("embedding_now max is %f" % recommender.embedding.get_value().max())
                print ("-1 item num is %d" % default_num)
                print num_users
if __name__ == '__main__':
    main()
