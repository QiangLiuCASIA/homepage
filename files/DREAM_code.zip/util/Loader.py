#!usr/bin/env python
# -*- coding:utf-8 -*-
import numpy as np
import math
from os import path
from collections import OrderedDict
import gc
import json
import random


def count_basket(data):
    num_basket = []
    for line in data:
        num_basket.append([])
        for basket in line:
            if -1 in set(basket):
                i = 0
                while basket[i] > -1:
                    i += 1
                num_basket[-1].append(i)
            else:
                num_basket[-1].append(len(basket))
    return num_basket


def diction_unpack(vocab):
    return vocab['id2item'], vocab['item2id'], vocab['id2user'], vocab['user2id']


def tf(data, item_size):
    user_size = len(data)
    tf_users = np.zeros((user_size, item_size))
    buynum = 0
    for user_id,user_data in enumerate(data):
        for everybasket in user_data:
            for every_item in everybasket:
                if every_item > -1:
                    tf_users[user_id][every_item] += 1
                    buynum += 1
    return  tf_users/buynum


def tf_basket(basket, item_size, buynum):
    tf_baskets = np.zeros(item_size)
    for every_item in basket:
        tf_baskets[every_item] += 1./buynum
    return tf_baskets


def df(data, item_size):
    user_size = len(data)
    df_items = np.ones(item_size)
    for user_id, user_data in enumerate(data):
        flag = np.zeros(item_size)
        for everybasket in user_data:
            for every_item in everybasket:
                if every_item > -1 and (not flag[every_item]):
                    df_items[every_item] += 1.0
                    flag[every_item] = 1
    return np.log(user_size/df_items)


def df_basket(data, item_size):
    df_items = np.ones(item_size)
    n_basket = 0
    for user_id, user_data in enumerate(data):
        for everybasket in user_data:
            n_basket += 1
            flag = np.zeros(item_size)
            for every_item in everybasket:
                if every_item > -1 and (not flag[every_item]):
                    df_items[every_item] += 1.0
                    flag[every_item] = 1
    return np.log(n_basket/df_items)


def tfidf_rank(data, item_size):
    tf_users = tf(data, item_size)
    df_items = df(data, item_size)
    user_size = tf_users.shape[0]
    np.tile(df_items, (user_size,1))
    tfidf = tf_users*df_items
    for user_id, user_data in enumerate(data):
        for basket_id, everybasket in enumerate(user_data):
            length = len(everybasket)
            for i in xrange(length-1):
                for j in xrange(length-i-1):
                    if (data[user_id][basket_id][i]>-1) and (data[user_id][basket_id][i+j+1]>-1) \
                            and (tfidf[user_id][i] < tfidf[user_id][i+j+1]):
                        temp = data[user_id][basket_id][i]
                        data[user_id][basket_id][i] = data[user_id][basket_id][i+j+1]
                        data[user_id][basket_id][i+j+1] = temp
    return data


def tfidf_basket_rank(data, item_size):
    buynum = 0  # 计算总共购买记录数
    for user_id, user_data in enumerate(data):
        for everybasket in user_data:
            for every_item in everybasket:
                if every_item > -1:
                    buynum += 1
    df_baskets = df_basket(data, item_size)
    for user_id, user_data in enumerate(data):
        for basket_id, everybasket in enumerate(user_data):
            tf_baskets = tf_basket(everybasket, item_size, buynum)
            tfidf_baskets = df_baskets*tf_baskets
            length = len(everybasket)
            for i in xrange(length-1):
                for j in xrange(length-i-1):
                    if (data[user_id][basket_id][i]>-1) and (data[user_id][basket_id][i+j+1]>-1) \
                            and (tfidf_baskets[i] < tfidf_baskets[i+j+1]):
                        temp = data[user_id][basket_id][i]
                        data[user_id][basket_id][i] = data[user_id][basket_id][i+j+1]
                        data[user_id][basket_id][i+j+1] = temp
    return data


class Loader(object):
    def __init__(self, which, data_dir, isrank):
        # self.n_users = n_users
        # self.n_items = n_items
        diction_file = path.join(data_dir, 'diction.npz')
        data_file = path.join(data_dir, 'data')
        # char_file = path.join(data_dir, 'data_char')
        if not (path.exists(diction_file) and path.exists(data_file+'.json')):
            print 'one-time setup: preprocessing input train/valid/test files in dir: ', data_dir
            if which == 'tafeng':
                self.init_tafeng(isrank=isrank)
            elif which == 'tmall':
                self.init_tmall(isrank=isrank)
            else:
                print ("wrong dataset name")
                assert 0
        print('loading data files...')
        # all_data = []
        # all_data_char = []
        with open("{}.json".format(data_file)) as f:
            all_data = json.load(f)
        diction_mapping = np.load(diction_file)
        self.id2item, self.item2id, self.id2user, self.user2id = diction_unpack(diction_mapping)
        self.item_size = len(self.id2item)
        self.user_size = len(self.id2user)
        self.max_basket_l = len(all_data[0][0])
        # self.seq_length = seq_length
        self.data_sizes = []
        self.split_sizes = [0, 0, 0]
        self.all_data = all_data
        self.batch_idx = -1
        self.item_size = len(self.id2item)
        self.user_size = len(self.id2user)
        # 看看总共有多少预测商品数
        self.predict_num = 1
        for users_idx,users in enumerate(self.all_data):
            if not users:
                assert users != []
            if len(users) < 3:
                continue
            final_basket = users[-1]
            i = 0
            while i < len(final_basket) and final_basket[i] > -1:
                self.predict_num += 1
                i += 1
        # 随机生成负样本
        self.basket_num = count_basket(self.all_data)
        print 'data load done. Numbers of users: %d, items: %d' \
            % (self.user_size, self.item_size)
        gc.collect()

    def reset_batch_pointer(self, batch_idx= -1):
        self.batch_idx = batch_idx

    def next_user(self):
        while self.batch_idx < self.user_size - 1:
            self.batch_idx += 1
            idx = self.batch_idx
            # idx = int(random.random() * self.user_size)
            chars = self.all_data[idx]
            size_basket = self.basket_num[idx]
            yield chars, size_basket

    def init_tafeng(self, isrank, data_dir="data/tafeng", data_names=('D11', 'D12', 'D01', 'D02')):
        all_data = OrderedDict()
        items_id = []
        items_num = []
        users_id = []
        users_num = []
        items_id2index = {}
        users_id2index = {}
        for dataname in data_names:
            full_pathname = path.join(data_dir, dataname)
            all_data[dataname] = OrderedDict()
            all_data[dataname]["date"] = []
            all_data[dataname]["item_id"] = []
            all_data[dataname]["item_num"] = []
            all_data[dataname]["user_id"] = []
            fid = open(full_pathname, 'r')
            labels = fid.readline()  # 第一行是标签
            for line in fid:
                temp = line.split(";")
                if not (temp[5] in set(items_id)):
                    items_id.append(temp[5])
                    items_num.append(1)
                    items_id2index[temp[5]] = len(items_id) - 1
                else:
                    items_num[items_id2index[temp[5]]] += 1
                if not (temp[1] in set(users_id)):
                    users_id.append(temp[1])
                    users_num.append(1)
                    users_id2index[temp[1]] = len(users_id) - 1
                else:
                    users_num[users_id2index[temp[1]]] += 1
                all_data[dataname]["date"].append(temp[0])
                all_data[dataname]["item_id"].append(temp[5])
                all_data[dataname]["item_num"].append(int(temp[6]))
                all_data[dataname]["user_id"].append(temp[1])
        num_items = len(items_id)
        num_users = len(users_id)
        del_indexset_items = []
        del_indexset_users = []
        for index, num in enumerate(items_num):
            if num < 10:
                del_indexset_items.append(items_id[index])
        del_indexset_items = set(del_indexset_items)
        for index, num in enumerate(users_num):
            if num < 10:
                del_indexset_users.append(users_id[index])
        del_indexset_users = set(del_indexset_users)
        # 数据输入完成，下面开始进行数据处理
        # 把小于10次记录的user和item删掉
        for k in xrange(4):
            assert len(all_data[data_names[k]]["item_id"]) == len(all_data[data_names[k]]["user_id"])
            assert len(all_data[data_names[k]]["date"]) == len(all_data[data_names[k]]["user_id"])
            assert len(all_data[data_names[k]]["date"]) == len(all_data[data_names[k]]["item_num"])
            j = 0
            length = len(all_data[data_names[k]]["date"])
            while j < length:
                if ((all_data[data_names[k]]["user_id"][j] in del_indexset_users
                     ) or (all_data[data_names[k]]["item_id"][j] in del_indexset_items)):
                    del all_data[data_names[k]]["date"][j]
                    del all_data[data_names[k]]["item_id"][j]
                    del all_data[data_names[k]]["item_num"][j]
                    del all_data[data_names[k]]["user_id"][j]
                    length -= 1
                else:
                    j += 1
        # 按照新的数据集重新建立映射列表，并且修改id
        items_id = []
        users_id = []
        items_id2index = {}
        users_id2index = {}
        for k in xrange(4):
            length = len(all_data[data_names[k]]["date"])
            for i in xrange(length):
                if not all_data[data_names[k]]["item_id"][i] in set(items_id):
                    items_id.append(all_data[data_names[k]]["item_id"][i])
                    items_id2index[all_data[data_names[k]]["item_id"][i]] = len(items_id) - 1
                all_data[data_names[k]]["item_id"][i] = items_id2index[all_data[data_names[k]]["item_id"][i]]
                if not all_data[data_names[k]]["user_id"][i] in set(users_id):
                    users_id.append(all_data[data_names[k]]["user_id"][i])
                    users_id2index[all_data[data_names[k]]["user_id"][i]] = len(users_id) - 1
                all_data[data_names[k]]["user_id"][i] = users_id2index[all_data[data_names[k]]["user_id"][i]]
        # 篮子化
        data = [[[]]]
        num_users = len(users_id)
        for i in xrange(num_users-1):
            data.append([])
        temp_date = all_data[data_names[0]]["date"][0]
        temp_user = all_data[data_names[0]]["user_id"][0]

        for k in xrange(4):
            length = len(all_data[data_names[k]]["date"])
            for i in xrange(length):
                if all_data[data_names[k]]["date"][i] == temp_date:
                    if all_data[data_names[k]]["user_id"][i] == temp_user:
                        for j in xrange(all_data[data_names[k]]["item_num"][i]):  # 买多个的分开算
                            data[temp_user][-1].append(all_data[data_names[k]]["item_id"][i])
                    else:
                        temp_user = all_data[data_names[k]]["user_id"][i]
                        data[temp_user].append([all_data[data_names[k]]["item_id"][i]])
                else:
                    temp_date = all_data[data_names[k]]["date"][i]
                    temp_user = all_data[data_names[k]]["user_id"][i]
                    data[temp_user].append([all_data[data_names[k]]["item_id"][i]])
        del all_data
        # 把篮子补充成同维度的矩阵
        # max_basket = max(max(max(data)))
        max_basket = 0
        length = len(data)
        for i in xrange(length):
            if len(data[i]) == 0:
                print i
                # assert len(data[i]) != 0
            for j in xrange(len(data[i])):
                if max_basket < len(data[i][j]):
                    max_basket = len(data[i][j])

        for i in xrange(length):
            for l in xrange(len(data[i])):
                temp_re = max_basket - len(data[i][l])
                for j in xrange(temp_re):
                    data[i][l].append(-1)
        # data = np.array(data)
        self.max_basket_l = max_basket
        if isrank:
            data = tfidf_basket_rank(data, len(items_id))
        # 把分好的篮子数据写进文件里
        outputfile = "data"
        # 训练数据
        # length = data.shape[0]
        # train_data = data[:][0:int(length*0.6)]
        # np.save(path.join(data_dir, outputfile+"_0.npy"), train_data)
        # train_data = [[data[i][j] for j in xrange(int(len(data_l)*0.6))] for data_l in data]
        train_data = [[data_l[j] for j in xrange(int(len(data_l)))] for data_l in data]
        with open(path.join(data_dir, outputfile+".json"),"w") as f:
            json.dump(train_data, f)


        # 把隐射关系存入文件
        diction_data = OrderedDict()
        diction_data["id2item"] = items_id
        diction_data["item2id"] = items_id2index
        diction_data["id2user"] = users_id
        diction_data["user2id"] = users_id2index
        np.savez(path.join(data_dir, "diction.npz"),
                 id2item=items_id, item2id=items_id2index, id2user=users_id, user2id=users_id2index)
        gc.collect()

    def init_tmall(self, isrank, data_dir="data/tmall", data_names='t_alibaba_data.csv'):
        all_data = OrderedDict()
        items_id = []
        items_num = []
        users_id = []
        users_num = []
        items_id2index = {}
        users_id2index = {}
        dataname = data_names
        full_pathname = path.join(data_dir, dataname)
        all_data["date"] = []
        all_data["item_id"] = []
        # all_data[dataname]["item_num"] = []
        all_data["user_id"] = []
        fid = open(full_pathname, 'r')
        labels = fid.readline()  # 第一行是标签
        for line in fid:
            temp = line.split(",")
            if not (temp[1] in set(items_id)):
                items_id.append(temp[1])
                items_num.append(1)
                items_id2index[temp[1]] = len(items_id) - 1
            else:
                items_num[items_id2index[temp[1]]] += 1
            if not (temp[0] in set(users_id)):
                users_id.append(temp[0])
                users_num.append(1)
                users_id2index[temp[0]] = len(users_id) - 1
            else:
                users_num[users_id2index[temp[0]]] += 1
            all_data["date"].append(temp[3])
            all_data["item_id"].append(temp[1])
            # all_data[dataname]["item_num"].append(int(temp[6]))
            all_data["user_id"].append(temp[0])
        num_items = len(items_id)
        num_users = len(users_id)
        del_indexset_items = []
        del_indexset_users = []
        for index, num in enumerate(items_num):
            if num < 3:
                del_indexset_items.append(items_id[index])
        del_indexset_items = set(del_indexset_items)
        for index, num in enumerate(users_num):
            if num < 3:
                del_indexset_users.append(users_id[index])
        del_indexset_users = set(del_indexset_users)
        # 数据输入完成，下面开始进行数据处理
        # 把小于10次记录的user和item删掉
        assert len(all_data["item_id"]) == len(all_data["user_id"])
        assert len(all_data["date"]) == len(all_data["user_id"])
        j = 0
        length = len(all_data["date"])
        while j < length:
            if ((all_data["user_id"][j] in del_indexset_users
                 ) or (all_data["item_id"][j] in del_indexset_items)):
                del all_data["date"][j]
                del all_data["item_id"][j]
                # del all_data[data_names[k]]["item_num"][j]
                del all_data["user_id"][j]
                length -= 1
            else:
                j += 1
        # 按照新的数据集重新建立映射列表，并且修改id
        items_id = []
        users_id = []
        items_id2index = {}
        users_id2index = {}

        length = len(all_data["date"])
        for i in xrange(length):
            if not all_data["item_id"][i] in set(items_id):
                items_id.append(all_data["item_id"][i])
                items_id2index[all_data["item_id"][i]] = len(items_id) - 1
            all_data["item_id"][i] = items_id2index[all_data["item_id"][i]]
            if not all_data["user_id"][i] in set(users_id):
                users_id.append(all_data["user_id"][i])
                users_id2index[all_data["user_id"][i]] = len(users_id) - 1
            all_data["user_id"][i] = users_id2index[all_data["user_id"][i]]
        # 篮子化
        data = [[[]]]
        num_users = len(users_id)
        for i in xrange(num_users-1):
            data.append([])
        temp_date = all_data["date"][0]
        temp_user = all_data["user_id"][0]
        length = len(all_data["date"])
        for i in xrange(length):
            if all_data["date"][i] == temp_date:
                if all_data["user_id"][i] == temp_user:
                    # for j in xrange(all_data["item_num"][i]):  # 买多个的分开算
                    data[temp_user][-1].append(all_data["item_id"][i])
                else:
                    temp_user = all_data["user_id"][i]
                    data[temp_user].append([all_data["item_id"][i]])
            else:
                temp_date = all_data["date"][i]
                temp_user = all_data["user_id"][i]
                data[temp_user].append([all_data["item_id"][i]])
        del all_data
        # 把篮子补充成同维度的矩阵
        # max_basket = max(max(max(data)))
        max_basket = 0
        length = len(data)
        for i in xrange(length):
            if len(data[i]) == 0:
                print i
                # assert len(data[i]) != 0
            for j in xrange(len(data[i])):
                if max_basket < len(data[i][j]):
                    max_basket = len(data[i][j])

        for i in xrange(length):
            for l in xrange(len(data[i])):
                temp_re = max_basket - len(data[i][l])
                for j in xrange(temp_re):
                    data[i][l].append(-1)
        # data = np.array(data)
        self.max_basket_l = max_basket
        if isrank:
            data = tfidf_basket_rank(data, len(items_id))
        # 把分好的篮子数据写进文件里
        outputfile = "data"
        # 训练数据
        # length = data.shape[0]
        # train_data = data[:][0:int(length*0.6)]
        # np.save(path.join(data_dir, outputfile+"_0.npy"), train_data)
        # train_data = [[data[i][j] for j in xrange(int(len(data_l)*0.6))] for data_l in data]
        train_data = [[data_l[j] for j in xrange(int(len(data_l)))] for data_l in data]
        with open(path.join(data_dir, outputfile+".json"),"w") as f:
            json.dump(train_data, f)
        # 把隐射关系存入文件
        diction_data = OrderedDict()
        diction_data["id2item"] = items_id
        diction_data["item2id"] = items_id2index
        diction_data["id2user"] = users_id
        diction_data["user2id"] = users_id2index
        np.savez(path.join(data_dir, "diction.npz"),
                 id2item=items_id, item2id=items_id2index, id2user=users_id, user2id=users_id2index)
        gc.collect()