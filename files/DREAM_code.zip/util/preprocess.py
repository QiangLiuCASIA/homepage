#!/usr/bin/env python
# -*- coding: utf-8 -*-
import random
import numpy as np


def negative(users_rank, num_items):
    negtargets = []
    for i in xrange(len(users_rank)):
        negtargets.append([])
        for j in xrange(len(users_rank[i])):
            if users_rank[i][j] == -1:  # 空物品还是给空物品
                k = -1
            else:
                k = random.randint(0, num_items-1)
                while k in set(users_rank[i]):
                    k = random.randint(0, num_items-1)
            negtargets[i].append(k)
    return negtargets
