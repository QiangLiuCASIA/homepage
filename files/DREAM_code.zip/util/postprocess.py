#!/usr/bin/env python
# -*- coding: utf-8 -*-
import numpy as np
import math
import json
from os import path


def f1_score5(pre_y, test_y, defult_none): # 在test中空item是-1，但是在pre中空的是最大编号
    # 把单个的三个量算好之后，放到主程序里面算整个的
    # test_y 实际值
    # pre_Y  预测值
    tp = 0.0
    fn = 0.0
    fp = 0.0
    for y in pre_y:
        if y != defult_none:
            if y not in set(test_y):
                fp += 1
    for y in test_y:
        if y != -1:
            if y not in set(pre_y):
                fn += 1
            else:
                tp += 1
    return tp, fn, fp


def ndcg5(pre_y, test_y, defult_none):
    # 待讨论
    # test_y 实际值
    # pre_y预测值
    length_pre = len(pre_y)
    assert length_pre == 5
    length_test = 0
    # while length_test < len(test_y) and test_y[length_test] > -1:
    #     length_test += 1
    test_y = list(set(test_y))
    for test in test_y:
        if test != -1:
            length_test += 1
    s = 0
    for i in xrange(length_pre):
        if pre_y[i] != defult_none:
            if pre_y[i] in set(test_y):
                if i == 0:
                    s += 1
                else:
                    s += 1.0/math.log(i+1)

    # 求ideal
    z = 1
    for i in xrange(length_test - 1):
        z += 1.0/math.log(i+2)
    # for i in xrange(length_pre-t):
    #     z += (1.0 -1)/math.log(i+t+2, 2)
    # if s == 0 and z == 0:
    #     ndcg = 0
    # else:
    ndcg = s/z
    return ndcg


def prediction_save(folder, name, result):
    for i in xrange(len(result)):
        for j in xrange(len(result[i])):
            result[i][j] = float(result[i][j])
    with open(path.join(folder, name + ".json"), "w") as f:
        json.dump(result, f)
