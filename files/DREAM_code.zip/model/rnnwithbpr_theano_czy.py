#!/usr/bin/env python
# -*- coding: utf-8 -*-
import theano
import numpy as np
import theano.tensor as T
import os
from theano.tensor.signal import pool
# from IPython.display import SVG
from model.convolutional_mlp import LeNetConvPoolLayer


class RCnnWithBpr(object):
    def __init__(self, n_basket,  n_hidden, n_vocabulary, n_embedding_dimension):
        # n_window 为把几个记录放在一起输入训练(或许可以增强序列感)
        # 使得x为n_embedding_dimension*n_window维向量
        # 词向量(广泛的说，是item的特性向量)的转化矩阵
        iscnn = False
        iscostplus = True
        nkerns = n_embedding_dimension  # 貌似可以不等于！！！！！！！！先留着
        filter_shape = (nkerns, 1, n_basket, 1)
        rng = np.random.RandomState(23455)
        poolsize = (1, n_embedding_dimension)
        # assert n_window == 1
        print "1、神经元参数构造............",
        embedding = np.random.uniform(-0.5, 0.5, (n_vocabulary, n_embedding_dimension)).astype(theano.config.floatX)
        embedding[-1] = 0.
        self.embedding = theano.shared(
            value=embedding.astype(theano.config.floatX),
            name='embedding',
            borrow=True
        )
        # 简单的把-1（空item）定义为一个属性似乎不太妥，但是想不到什么好的改变的办法
        #  x乘u
        self.u = theano.shared(
            value=np.random.uniform(-0.5, 0.5, (nkerns, n_hidden)).astype(theano.config.floatX),
            #                               这个维度应该跟cnn输出的向量维度一样需要修改
            name='u',
            borrow=True
        )
        #  h乘w
        self.w = theano.shared(
            value=np.random.uniform(-0.5, 0.5, (n_hidden, n_hidden)).astype(theano.config.floatX),
            name='w',
            borrow=True
        )
        # #  h乘v
        # self.v = theano.shared(
        #     value=np.random.uniform(-0.5, 0.5, (n_hidden, n_embedding_dimension * n_window)).astype(theano.config.floatX),
        #     name='v',
        #     borrow=True
        # )
        self.hidden_lay0 = theano.shared(
            value=np.zeros(n_hidden, dtype=theano.config.floatX),
            name='hidden_lay0',
            borrow=True
        ) # ！！
        fan_in = np.prod(filter_shape[1:])
        fan_out = (filter_shape[0] * np.prod(filter_shape[2:]) // np.prod(poolsize))
        # initialize weights with random weights
        W_bound = np.sqrt(6. / (fan_in + fan_out))
        self.w_cnn = theano.shared(
            np.asarray(
                        rng.uniform(low=-W_bound, high=W_bound, size=filter_shape),
                        dtype=theano.config.floatX
                        ),
            borrow=True
        )
        b_values = np.zeros((filter_shape[0],), dtype=theano.config.floatX)
        # self.b = theano.shared(value=b_values, borrow=True)
        self.b_cnn = theano.shared(value=b_values, borrow=True)
        #  trace

        input_item_id = T.lmatrix('input_item_id')   # 即输入的的矩阵
        input_size = T.lvector('input_size')
        # next_item_id = T.lscalar('output_item_id')   # 即预测的 的矩阵
        # n_batch = T.iscalar('n_batch')
        neg_item_id = T.lmatrix('neg_item_id')
        x = self.embedding[input_item_id].reshape((input_item_id.shape[0], n_basket, n_embedding_dimension))
        x.name = 'x'
        # y = self.embedding[next_item_id].reshape((1, n_window * n_embedding_dimension))[0]
        neg = self.embedding[neg_item_id].reshape((neg_item_id.shape[0], n_basket, n_embedding_dimension))
        neg.name = 'neg'
        # 把经过embedding的特征矩阵先过一个cnn
        # ！！！注意要先把这里的卷积的
        if iscnn:
            cnn_x = LeNetConvPoolLayer(
                rng,
                input=x.reshape((x.shape[0], 1, n_basket, n_embedding_dimension)),
                image_shape=(None, 1, n_basket,  n_embedding_dimension),
                # 事实上image_shape这个变量几乎没有起作用，第一维随便写就行
                filter_shape=filter_shape,
                W=self.w_cnn,
                b=self.b_cnn,
                poolsize=poolsize
            )
            cnn_x_output = cnn_x.output.flatten(2)
            self.param = (self.embedding, self.u, self.w, self.w_cnn, self.b_cnn)  # , self.v)
            self.name = ('embedding', 'u', 'w', 'w_cnn','b_cnn')  # , 'v')
        else:
            # cnn_x = pool.pool_2d(
            #     input=x.reshape((x.shape[0], 1, n_basket, n_embedding_dimension)),
            #     ds=(n_basket, 1),
            #     ignore_border=False,  #
            #     mode='sum'
            # )
            def pooling_max(abasker_t, basket_size_t):
                pool_result_t = T.max(abasker_t[: basket_size_t], axis=0)
                return pool_result_t
            pool_result, _ = theano.scan(
                                        fn=pooling_max,
                                        sequences=[x.reshape((x.shape[0], n_basket, n_embedding_dimension)), input_size]
                                        )
            cnn_x = pool_result
            # input_pool = x.reshape((x.shape[0], 1, n_basket, n_embedding_dimension))
            # T.argsort(input_pool, axis=2)[-1]
            cnn_x_output = cnn_x.flatten(2)
            self.param = (self.embedding, self.u, self.w)  # , self.v)
            self.name = ('embedding', 'u', 'w')  # , 'v')

        print("完成")
        print "2、损失函数构造..............",

        def recurrence(x_t, h_tml):
            #  定义循环运算函数
            h_t = T.nnet.sigmoid(T.dot(x_t, self.u) + T.dot(h_tml, self.w))
            return h_t  #
        h, _ = theano.scan(
            fn=recurrence,
            sequences=cnn_x_output,
            outputs_info=[self.hidden_lay0]
            #n_steps=n_batch - 1
        )
        h.name = 'h'
        self.user_feature = h[-1, :]  #
        self.user_feature.name = 'user_feature'
        # p_y_given_xwhole = s[:, 0, :]
        #  损失函数
        if iscostplus:
            def cla_cost(x_t, h_t):
                #  定义循环运算函数
                s_tt = T.dot((x[x_t+1][:input_size[x_t+1]] - neg[x_t+1][:input_size[x_t+1]]), h_t)
                s_t = T.sum(T.log(1 + T.exp(-s_tt)))
                # s_t = T.sum(x[x_t+1][:input_size[x_t+1]] - neg[x_t+1][:input_size[x_t+1]], axis=0)
                return s_t
            s, _ = theano.scan(
                fn=cla_cost,
                sequences=[T.arange(x.shape[0]-1), h]
                # outputs_info=[self.hidden_lay0, None],
                # n_steps=x.shape[0]-1
            )
            cost = T.sum(s)
        else:
            cost_temp = T.dot(x[-1][:input_size[-1]], h[-2]) - T.dot(neg[-1][:input_size[-1]], h[-2])
            cost = T.sum(T.log(1 + T.exp(-cost_temp)))

        print("完成")
        print"3、随机梯度递降更新公式......",
        # 更新
        learning_rate = T.dscalar('learning_rate')
        lamda = T.dscalar('lamda')
        # gradient = T.grad(nll, self.param)
        gradient = T.grad(cost, self.param)
        # theano.printing.pydotprint(gradient, outfile="E:/PycharmProjects/learningtheano/logreg.png", var_with_name_simple=True)
        # self.gradient = gradient
        updates = [(p, p - learning_rate * (g + p * lamda)) for p, g in zip(self.param, gradient)]
        # updates.append((self.hidden_lay0, h_update))
        print("完成")
        print"4、预测函数定义..............",
        y_pred = T.argsort(T.dot(self.embedding, self.user_feature))[-6:]
        self.predict = theano.function(inputs=[input_item_id, input_size], outputs=y_pred[-1])
        # theano.printing.debugprint(y_pred)
        # theano.printing.pydotprint(self.predict, outfile="E:/PycharmProjects/learningtheano/logreg.png", var_with_name_simple=True)
        print("完成")
        print"5、训练函数定义..............",
        self.train = theano.function(inputs=[input_item_id, neg_item_id, input_size, learning_rate, lamda],
                                     outputs=cost,  # [cost],
                                     updates=updates)
        # theano.pprint(cost)
        print("完成")
        print"6、评价函数定义..............",
        self.evaluation_recall_6 = theano.function(inputs=[input_item_id, input_size], outputs=y_pred)
        print("完成")
        self.normalize = theano.function(inputs=[],
                                         updates={self.embedding:\
                                         self.embedding/T.sqrt((self.embedding**2).sum(axis=1)).dimshuffle(0, 'x')*10})
        # # test
        # self.test_cost = theano.function(inputs=[input_item_id, neg_item_id], outputs=x[-1] - neg[-1])
        # self.test_h = theano.function(inputs=[input_item_id, neg_item_id, input_size], outputs=s)
        # self.test_cnnflat = theano.function(inputs=[input_item_id], outputs=cnn_x_output)

    def init_hidden_layer(self):   # 貌似没用
        n_out = self.hidden_lay0.shape[0]
        self.hidden_lay0.set_value(np.zeros(n_out, dtype=theano.config.floatX))

    def save_params(self, folder):
        for paramtemp, nametemp in zip(self.param, self.name):
            np.save(os.path.join(folder, nametemp + '.npy'), paramtemp.get_value())

    def load_params(self, folder):
        for paramtemp, nametemp in zip(self.param, self.name):
            paramtemp.set_value(np.load(os.path.join(folder, nametemp + '.npy')))
