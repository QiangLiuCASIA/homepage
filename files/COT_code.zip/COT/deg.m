function [cost, grad] = deg(parameter, data, sizes, lambda)
cost = 0;
grad = zeros(length(parameter),1);

user = data(1);
item = data(2);
vir = data(3)+1;
sit = data(4)+1;
score = data(5);

base = 0;
temp = sizes(1)*sizes(2);
U = reshape(parameter(base+1:base+temp),sizes(1),sizes(2));
base = base+temp;
temp = sizes(3)*sizes(4);
I = reshape(parameter(base+1:base+temp),sizes(3),sizes(4));
base = base+temp;
temp = sizes(5)*sizes(6);
Cv = reshape(parameter(base+1:base+temp),sizes(5),sizes(6));
base = base+temp;
temp = sizes(7)*sizes(8);
Cs = reshape(parameter(base+1:base+temp),sizes(7),sizes(8));
base = base+temp;
temp = sizes(9);
P = reshape(parameter(base+1:base+temp),sizes(9),1);
base = base+temp;
temp = sizes(10)*sizes(11)*sizes(12);
T1 = reshape(parameter(base+1:base+temp),sizes(10),sizes(11),sizes(12));
base = base+temp;
temp = sizes(13)*sizes(14)*sizes(15);
T2 = reshape(parameter(base+1:base+temp),sizes(13),sizes(14),sizes(15));
nC = sizes(10);
nUI = sizes(11);

UT = zeros(nUI,1);
for i=1:nUI
    UT(i) = ([Cv(:,vir),Cs(:,sit)]*P)'*T1(:,:,i)*U(:,user);
end
IT = zeros(nUI,1);
for i=1:nUI
    IT(i) = ([Cv(:,vir),Cs(:,sit)]*P)'*T2(:,:,i)*I(:,item);
end

rec = UT'*IT;
cost = score-rec;

base = 0;
gU = zeros(nUI,1);
for i=1:nUI
    gU = gU + (([Cv(:,vir),Cs(:,sit)]*P)'*T1(:,:,i)*IT(i))';
end
gU = -gU*cost;
grad(base+(user-1)*nUI+1:base+user*nUI) = gU;
base = base+sizes(1)*sizes(2);

gI = zeros(nUI,1);
for i=1:nUI
    gI = gI + (([Cv(:,vir),Cs(:,sit)]*P)'*T2(:,:,i)*UT(i))';
end
gI = -gI*cost;
grad(base+(item-1)*nUI+1:base+item*nUI) = gI;
base = base+sizes(3)*sizes(4);

gC = zeros(nC,2);
for i=1:nUI
    gC = gC+T1(:,:,i)*U(:,user)*IT(i)*P'+T2(:,:,i)*I(:,item)*UT(i)*P';
end
gC1 = -gC(:,1)*cost;
grad(base+(vir-1)*nC+1:base+vir*nC) = gC1;
base = base+sizes(5)*sizes(6);
gC2 = -gC(:,2)*cost;
grad(base+(sit-1)*nC+1:base+sit*nC) = gC2;
base = base+sizes(7)*sizes(8);

gP = zeros(2,1);
for i=1:nUI
    gP = gP+[Cv(:,vir),Cs(:,sit)]'*T1(:,:,i)*U(:,user)*IT(i)+[Cv(:,vir),Cs(:,sit)]'*T2(:,:,i)*I(:,item)*UT(i);
end
gP = -gP*cost;
grad(base+1:base+2) = gP;
base = base+sizes(9);

gT1 = zeros(nC,nUI,nUI);
for i=1:nUI
    gT1(:,:,i) = [Cv(:,vir),Cs(:,sit)]*P*U(:,user)'*IT(i);
end
gT1 = -gT1*cost;
gT1 = reshape(gT1,nC*nUI*nUI,1);
grad(base+1:base+nC*nUI*nUI) = gT1;
base = base+sizes(10)*sizes(11)*sizes(12);

gT2 = zeros(nC,nUI,nUI);
for i=1:nUI
    gT2(:,:,i) = [Cv(:,vir),Cs(:,sit)]*P*I(:,item)'*UT(i);
end
gT2 = -gT2*cost;
gT2 = reshape(gT2,nC*nUI*nUI,1);
grad(base+1:base+nC*nUI*nUI) = gT2;

cost = abs(cost);
