function cost = lossAll(parameter, data, sizes, biases)
cost = 0;

for i=1:length(data)
   cost0 = loss(parameter, data(i,:), sizes, biases);
   cost = cost+cost0^2;
end

cost = cost/length(data);
cost = cost^.5;