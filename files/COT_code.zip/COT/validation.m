function res = validation(w0, wu, wi, wv, ws, parameter, sizes)

load test.csv;
users = test(:,1);
items = test(:,2);
virs = test(:,3);
sits = test(:,4);
scores = test(:,5);

rec = zeros(length(scores),1);
biases = zeros(length(scores),1);
for i = 1:length(scores)
    bias = w0+wu(users(i))+wi(items(i))+wv(virs(i)+1)+ws(sits(i)+1);
    rec(i) = scores(i)-bias;
    biases(i) = bias;
end

data = [users,items,virs,sits,rec];
res = lossAll(parameter, data, sizes, biases);