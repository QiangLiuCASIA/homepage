function [cost, grad] = cal(parameter, data, sizes, lambda)
cost = 0;
grad = zeros(length(parameter),1);

for i=1:size(data)
   [cost0, grad0] = deg(parameter, data(i,:), sizes, lambda);
   cost = cost+cost0;
   grad = grad+grad0;
end

cost = cost+parameter'*parameter*lambda/2;
grad = grad+parameter*lambda;