function error_final = check(a,b)

clc

nUI = a;
nC = b;
lambda = 0.001;

load train.csv;
users = train(:,1);
items = train(:,2);
virs = train(:,3);
sits = train(:,4);
scores = train(:,5);

w0 = 0;
wu = zeros(max(users),1);
wi = zeros(max(items),1);
wv = zeros(max(virs)+1,1);
ws = zeros(max(sits)+1,1);

w0 = mean(scores);
for i=1:max(users)
    wu(i) = mean(scores(users==i))-w0;
end
for i=1:max(items)
    wi(i) = mean(scores(items==i))-w0;
end
for i=1:max(virs)+1
    wv(i) = mean(scores(virs==i-1))-w0;
end
for i=1:max(sits)+1
    ws(i) = mean(scores(sits==i-1))-w0;
end

rec = zeros(length(scores),1);
biases = zeros(length(scores),1);
for i = 1:length(scores)
    bias = w0+wu(users(i))+wi(items(i))+wv(virs(i)+1)+ws(sits(i)+1);
    rec(i) = scores(i)-bias;
    biases(i) = bias;
end

addpath(genpath('toolbox'));
options.Method = 'lbfgs';
options.maxIter = 5;
options.display = 'off';
options.DerivativeCheck = 'off';

U = rand(nUI,max(users))*0.5-0.25;
I = rand(nUI,max(items))*0.5-0.25;
Cv = rand(nC,max(virs)+1)*0.5-0.25;
Cs = rand(nC,max(sits)+1)*0.5-0.25;
P = [0.5,0.5]';
T1 = rand(nC,nUI,nUI)*0.5-0.25;
T2 = rand(nC,nUI,nUI)*0.5-0.25;

parameter = [];
sizes = [];
[m,n] = size(U);
sizes = [sizes,m,n];
parameter = [parameter;reshape(U,m*n,1)];
[m,n] = size(I);
sizes = [sizes,m,n];
parameter = [parameter;reshape(I,m*n,1)];
[m,n] = size(Cv);
sizes = [sizes,m,n];
parameter = [parameter;reshape(Cv,m*n,1)];
[m,n] = size(Cs);
sizes = [sizes,m,n];
parameter = [parameter;reshape(Cs,m*n,1)];
sizes = [sizes,length(P)];
parameter = [parameter;P];
[m,n,p] = size(T1);
sizes = [sizes,m,n,p];
parameter = [parameter;reshape(T1,m*n*p,1)];
[m,n,p] = size(T2);
sizes = [sizes,m,n,p];
parameter = [parameter;reshape(T2,m*n*p,1)];

data = [users,items,virs,sits,rec];
lossAll(parameter, data, sizes, biases)
validation(w0, wu, wi, wv, ws, parameter, sizes);

m1 = [];
m2 = [];

for k=1:25
    data = [users,items,virs,sits,rec];
    [parameter, cost] = minFunc(@(p) cal(p, data, sizes, lambda),parameter, options);

    data = [users,items,virs,sits,rec];
    lossAll(parameter, data, sizes, biases)
    validation(w0, wu, wi, wv, ws, parameter, sizes)
    
    base = 0;
    temp = sizes(1)*sizes(2);
    U = reshape(parameter(base+1:base+temp),sizes(1),sizes(2));
    base = base+temp;
    temp = sizes(3)*sizes(4);
    I = reshape(parameter(base+1:base+temp),sizes(3),sizes(4));
    base = base+temp;
    temp = sizes(5)*sizes(6);
    Cv = reshape(parameter(base+1:base+temp),sizes(5),sizes(6));
    base = base+temp;
    temp = sizes(7)*sizes(8);
    Cs = reshape(parameter(base+1:base+temp),sizes(7),sizes(8));
    base = base+temp;
    temp = sizes(9);
    P = reshape(parameter(base+1:base+temp),sizes(9),1);
    base = base+temp;
    temp = sizes(10)*sizes(11)*sizes(12);
    T1 = reshape(parameter(base+1:base+temp),sizes(10),sizes(11),sizes(12));
    base = base+temp;
    temp = sizes(13)*sizes(14)*sizes(15);
    T2 = reshape(parameter(base+1:base+temp),sizes(13),sizes(14),sizes(15));
    
    errors = 0;
    n = 0;
    for i=1:nUI
        for j=i+1:nUI
            n = n+1;
            errors = errors + (sum(sum((T1(:,:,i)-T1(:,:,j)).^2)')/(nUI*nC))^.5;
        end
    end
    m1 = [m1,errors/n];

    errors = 0;
    n = 0;
    for i=1:nUI
        for j=i+1:nUI
            n = n+1;
            errors = errors + (sum(sum((T2(:,:,i)-T2(:,:,j)).^2)')/(nUI*nC))^.5;
        end
    end
    m2 = [m2,errors/n];
end

base = 0;
temp = sizes(1)*sizes(2);
U = reshape(parameter(base+1:base+temp),sizes(1),sizes(2));
base = base+temp;
temp = sizes(3)*sizes(4);
I = reshape(parameter(base+1:base+temp),sizes(3),sizes(4));
base = base+temp;
temp = sizes(5)*sizes(6);
Cv = reshape(parameter(base+1:base+temp),sizes(5),sizes(6));
base = base+temp;
temp = sizes(7)*sizes(8);
Cs = reshape(parameter(base+1:base+temp),sizes(7),sizes(8));
base = base+temp;
temp = sizes(9);
P = reshape(parameter(base+1:base+temp),sizes(9),1);
base = base+temp;
temp = sizes(10)*sizes(11)*sizes(12);
T1 = reshape(parameter(base+1:base+temp),sizes(10),sizes(11),sizes(12));
base = base+temp;
temp = sizes(13)*sizes(14)*sizes(15);
T2 = reshape(parameter(base+1:base+temp),sizes(13),sizes(14),sizes(15));
