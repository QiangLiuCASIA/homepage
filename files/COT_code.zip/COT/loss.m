function cost = loss(parameter, data, sizes, biases)
cost = 0;

user = data(1);
item = data(2);
vir = data(3)+1;
sit = data(4)+1;
score = data(5);

base = 0;
temp = sizes(1)*sizes(2);
U = reshape(parameter(base+1:base+temp),sizes(1),sizes(2));
base = base+temp;
temp = sizes(3)*sizes(4);
I = reshape(parameter(base+1:base+temp),sizes(3),sizes(4));
base = base+temp;
temp = sizes(5)*sizes(6);
Cv = reshape(parameter(base+1:base+temp),sizes(5),sizes(6));
base = base+temp;
temp = sizes(7)*sizes(8);
Cs = reshape(parameter(base+1:base+temp),sizes(7),sizes(8));
base = base+temp;
temp = sizes(9);
P = reshape(parameter(base+1:base+temp),sizes(9),1);
base = base+temp;
temp = sizes(10)*sizes(11)*sizes(12);
T1 = reshape(parameter(base+1:base+temp),sizes(10),sizes(11),sizes(12));
base = base+temp;
temp = sizes(13)*sizes(14)*sizes(15);
T2 = reshape(parameter(base+1:base+temp),sizes(13),sizes(14),sizes(15));
nC = sizes(10);
nUI = sizes(11);

UT = zeros(nUI,1);
for i=1:nUI
    UT(i) = ([Cv(:,vir),Cs(:,sit)]*P)'*T1(:,:,i)*U(:,user);
end
IT = zeros(nUI,1);
for i=1:nUI
    IT(i) = ([Cv(:,vir),Cs(:,sit)]*P)'*T2(:,:,i)*I(:,item);
end

rec = UT'*IT;
if(rec>(5-biases(user)))
    rec = 5-biases(user);
end
if(rec<(1-biases(user)))
    rec = 1-biases(user);
end
cost = score-rec;

cost = abs(cost);
