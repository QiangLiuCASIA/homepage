function res = left_order(U, T)

[temp, m, n] = size(T);
res = zeros(n,m);
for i = 1:n
    res(i,:) = U'*T(:,:,i);
end