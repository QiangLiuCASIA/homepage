function res = right_order(T, V)

[m, temp, n] = size(T);
res = zeros(m,n);
for i = 1:n
    res(:,i) = T(:,:,i)*V;
end