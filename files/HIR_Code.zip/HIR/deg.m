function [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, U, V, C, T1, T2, W, nUI, flag)
fprintf('deg\n')
cost = 0;
gU = zeros(size(U));
gV = zeros(size(V));
gC = zeros(size(C));
gT1 = zeros(size(T1));
gT2 = zeros(size(T2));
gW = zeros(size(W));

for i=1:length(train)
    u = train(i,1);
    v = train(i,2);
    c = train(i,3);
    s = train(i,4);
    
    P1 = left_order(U(:,u),T1)*V(:,v);
    P2 = left_order(C(:,c),T2)*P1;
    rec = W'*P2;
    cost0 = s-rec;
    cost = cost+cost0^2;
    gP = left_order(C(:,c),T2)'*W;
    
    if flag==0
        gW = gW-P2*cost0*2;
        gC(:,c) = gC(:,c)-right_order(T2,P1)*W*cost0*2;
        gV(:,v) = gV(:,v)-left_order(U(:,u),T1)'*gP*cost0*2;
        gU(:,u) = gU(:,u)-right_order(T1,V(:,v))*gP*cost0*2;
        temp1 = C(:,c)*P1';
        temp2 = U(:,u)*V(:,v)';
        for j=1:nUI
           gT2(:,:,j) = gT2(:,:,j)-temp1*W(j)*cost0*2;
           gT1(:,:,j) = gT1(:,:,j)-temp2*gP(j)*cost0*2;
        end
    end
    
    if flag==1
        gU(:,u) = gU(:,u)-right_order(T1,V(:,v))*gP*cost0*2;
    end
    
    if flag==2
        gV(:,v) = gV(:,v)-left_order(U(:,u),T1)'*gP*cost0*2;
    end
    
    if flag==3
        gC(:,c) = gC(:,c)-right_order(T2,P1)*W*cost0*2;
    end
    
    if flag==4
        temp2 = U(:,u)*V(:,v)';
        for j=1:nUI
           gT1(:,:,j) = gT1(:,:,j)-temp2*gP(j)*cost0*2;
        end
    end
    
    if flag==5
        temp1 = C(:,c)*P1';
        for j=1:nUI
           gT2(:,:,j) = gT2(:,:,j)-temp1*W(j)*cost0*2;
        end
    end
    
    if flag==6
        gW = gW-P2*cost0*2;
    end
end
