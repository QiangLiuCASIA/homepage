function [cost, grad] = cal(parameter, train, U, V, C, T1, T2, W, nUI, nU, nC, nV, lambda, flag)
cost = 0;
grad = parameter*lambda;

if flag==0
    base = 0;
    U = reshape(parameter(base+1:base+nUI*nU),nUI,nU);
    base = base+nUI*nU;
    V = reshape(parameter(base+1:base+nUI*nV),nUI,nV);
    base = base+nUI*nV;
    C = reshape(parameter(base+1:base+nUI*nC),nUI,nC);
    base = base+nUI*nC;
    T1 = reshape(parameter(base+1:base+nUI*nUI*nUI),nUI,nUI,nUI);
    base = base+nUI*nUI*nUI;
    T2 = reshape(parameter(base+1:base+nUI*nUI*nUI),nUI,nUI,nUI);
    base = base+nUI*nUI*nUI;
    W = parameter(base+1:base+nUI);

    [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, U, V, C, T1, T2, W, nUI, flag);

    g_all = [];
    g_all = [g_all;reshape(gU, nUI*nU, 1)];
    g_all = [g_all;reshape(gV, nUI*nV, 1)];
    g_all = [g_all;reshape(gC, nUI*nC, 1)];
    g_all = [g_all;reshape(gT1, nUI*nUI*nUI, 1)];
    g_all = [g_all;reshape(gT2, nUI*nUI*nUI, 1)];
    g_all = [g_all;gW];

    grad = grad+g_all;
end

if flag==1
    Un = reshape(parameter,nUI,nU);
    [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, Un, V, C, T1, T2, W, nUI, flag);
    g_all = reshape(gU, nUI*nU, 1);
    grad = grad+g_all;
end

if flag==2
    Vn = reshape(parameter,nUI,nV);
    [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, U, Vn, C, T1, T2, W, nUI, flag);
    g_all = reshape(gV, nUI*nV, 1);
    grad = grad+g_all;
end

if flag==3
    Cn = reshape(parameter,nUI,nC);
    [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, U, V, Cn, T1, T2, W, nUI, flag);
    g_all = reshape(gC, nUI*nC, 1);
    grad = grad+g_all;
end

if flag==4
    T1n = reshape(parameter,nUI,nUI,nUI);
    [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, U, V, C, T1n, T2, W, nUI, flag);
    g_all = reshape(gT1, nUI*nUI*nUI, 1);
    grad = grad+g_all;
end

if flag==5
    T2n = reshape(parameter,nUI,nUI,nUI);
    [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, U, V, C, T1, T2n, W, nUI, flag);
    g_all = reshape(gT2, nUI*nUI*nUI, 1);
    grad = grad+g_all;
end

if flag==6
    Wn = parameter;
    [cost, gU, gV, gC, gT1, gT2, gW] = deg(train, U, V, C, T1, T2, Wn, nUI, flag);
    g_all = gW;
    grad = grad+g_all;
end




























