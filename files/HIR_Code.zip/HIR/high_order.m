function res = high_order(U, T, V)

[temp1, temp2, n] = size(T);
res = zeros(n,1);
for i = 1:n
    res(i) = U'*T(:,:,i)*V;
end