clear
clc

load train.csv
load test.csv
data = [train;test];

addpath(genpath('toolbox'));
options.Method = 'lbfgs';
options.maxIter = 5;
options.display = 'off';
options.DerivativeCheck = 'off';

nUI = 6;
lambda = 0.1;
nU = max(data(:,1));
nV = max(data(:,2));
nC = max(data(:,3));

w0 = 0;
wu = zeros(nU,1);
wv = zeros(nV,1);
wc = zeros(nC,1);

w0 = mean(train(:,4));
for i=1:nU
    if(sum(train(:,1)==i)>0)
        wu(i) = mean(train(train(:,1)==i,4))-w0;
    end
end
for i=1:nV
    if(sum(train(:,2)==i)>0)
        wv(i) = mean(train(train(:,2)==i,4))-w0;
    end
end
for i=1:nC
    if(sum(train(:,3)==i)>0)
        wc(i) = mean(train(train(:,3)==i,4))-w0;
    end
end

for i=1:length(train)
    train(i,4) = train(i,4)-w0-wu(train(i,1))-wv(train(i,2))-wc(train(i,3));
end
for i=1:length(test)
    test(i,4) = test(i,4)-w0-wu(test(i,1))-wv(test(i,2))-wc(test(i,3));
end

U = rand(nUI,nU)*0.5-0.25;
V = rand(nUI,nV)*0.5-0.25;
C = rand(nUI,nC)*0.5-0.25;
T1 = rand(nUI,nUI,nUI)*0.5-0.25;
T2 = rand(nUI,nUI,nUI)*0.5-0.25;
W = rand(nUI,1)*0.5-0.25;

% parameter = [];
% parameter = [parameter;reshape(U, nUI*nU, 1)];
% parameter = [parameter;reshape(V, nUI*nV, 1)];
% parameter = [parameter;reshape(C, nUI*nC, 1)];
% parameter = [parameter;reshape(T1, nUI*nUI*nUI, 1)];
% parameter = [parameter;reshape(T2, nUI*nUI*nUI, 1)];
% parameter = [parameter;W];
% 
% [parameter, cost] = minFunc(@(p) cal(p, train, nUI, nU, nC, nV, lambda, 0),parameter, options);
% 
% base = 0;
% U = reshape(parameter(base+1:base+nUI*nU),nUI,nU);
% base = base+nUI*nU;
% V = reshape(parameter(base+1:base+nUI*nV),nUI,nV);
% base = base+nUI*nV;
% C = reshape(parameter(base+1:base+nUI*nC),nUI,nC);
% base = base+nUI*nC;
% T1 = reshape(parameter(base+1:base+nUI*nUI*nUI),nUI,nUI,nUI);
% base = base+nUI*nUI*nUI;
% T2 = reshape(parameter(base+1:base+nUI*nUI*nUI),nUI,nUI,nUI);
% base = base+nUI*nUI*nUI;
% W = parameter(base+1:base+nUI);
% 
% lossAll(train, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
% lossAll(test, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)

parameter = reshape(U, nUI*nU, 1);
[parameter, cost] = minFunc(@(p) cal(p, train, U, V, C, T1, T2, W, nUI, nU, nC, nV, lambda, 1),parameter, options);
U = reshape(parameter,nUI,nU);
lossAll(train, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
lossAll(test, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)

parameter = reshape(V, nUI*nV, 1);
[parameter, cost] = minFunc(@(p) cal(p, train, U, V, C, T1, T2, W, nUI, nU, nC, nV, lambda, 2),parameter, options);
V = reshape(parameter,nUI,nV);
lossAll(train, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
lossAll(test, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)

parameter = reshape(C, nUI*nC, 1);
[parameter, cost] = minFunc(@(p) cal(p, train, U, V, C, T1, T2, W, nUI, nU, nC, nV, lambda, 3),parameter, options);
C = reshape(parameter,nUI,nC);
lossAll(train, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
lossAll(test, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)

parameter = reshape(T1, nUI*nUI*nUI, 1);
[parameter, cost] = minFunc(@(p) cal(p, train, U, V, C, T1, T2, W, nUI, nU, nC, nV, lambda, 4),parameter, options);
T1 = reshape(parameter,nUI,nUI,nUI);
lossAll(train, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
lossAll(test, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)

parameter = reshape(T2, nUI*nUI*nUI, 1);
[parameter, cost] = minFunc(@(p) cal(p, train, U, V, C, T1, T2, W, nUI, nU, nC, nV, lambda, 5),parameter, options);
T2 = reshape(parameter,nUI,nUI,nUI);
lossAll(train, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
lossAll(test, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)

parameter = W;
[parameter, cost] = minFunc(@(p) cal(p, train, U, V, C, T1, T2, W, nUI, nU, nC, nV, lambda, 6),parameter, options);
W = parameter;
lossAll(train, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
lossAll(test, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)



























