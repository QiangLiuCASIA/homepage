function cost = lossAll(data, U, V, C, T1, T2, W, w0, wu, wv, wc, nUI)
cost = 0;

for i=1:length(data)
    u = data(i,1);
    v = data(i,2);
    c = data(i,3);
    score = data(i,4);
    rec = W'*left_order(C(:,c),T2)*left_order(U(:,u),T1)*V(:,v);
    if(rec>(5-(w0+wu(u)+wv(v)+wc(c))))
        rec = 5-(w0+wu(u)+wv(v)+wc(c));
    end
    if(rec<(1-(w0+wu(u)+wv(v)+wc(c))))
        rec = 1-(w0+wu(u)+wv(v)+wc(c));
    end
    cost0 = score-rec;
    cost = cost+cost0^2;
end

cost = cost/length(data);
cost = cost^.5;